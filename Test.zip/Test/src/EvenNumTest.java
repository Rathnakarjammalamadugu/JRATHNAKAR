import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class EvenNumTest {
public static void main(String[] args) {
	System.out.println(" Hi ");
	/*
	 * List<Integer> myList = Arrays.asList(10,15,8,49,25,98,32,10,8);
	 * 
	 * String str ="Hello"; String str1 ="world";
	 * 
	 * System.out.println(" string before swap str :"+str +" "+str1); str = str +
	 * str1; str1 = str.substring(0,str.length()-str1.length()); str =
	 * str.substring(str1.length());
	 * 
	 * System.out.println(" string after swap str :" +str +" "+str1);
	 */
	
	
	String str ="I love Java";
	
	Map<String ,Long> result = Arrays.stream(str.split("")).map(String ::toLowerCase).
			collect(Collectors.groupingBy(s -> s, LinkedHashMap::new, Collectors.counting()));
	
			System.out.println("result "+result);
	
	
}
}
