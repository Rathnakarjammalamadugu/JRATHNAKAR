
public class Customer {
	
		String name;
	    int age;
	    String email;

	    // Constructor to initialize customer details
	    public Customer(String name, int age, String email) {
	        this.name = name;
	        this.age = age;
	        this.email = email;
	    }

	    // Method to display customer details
	    public void displayDetails() {
	        System.out.println("Customer Name: " + name);
	        System.out.println("Customer Age: " + age);
	        System.out.println("Customer Email: " + email);
	    }
	

	// Main class to test the Customer class
	
	    public static void main(String[] args) {
	        // Create a new customer
	        Customer customer1 = new Customer("Ratnakar",35, "rathn.infa@example.com");
	        Customer customer2 = new Customer("Ramesh",35, "Ramesh.infa@example.com");
	        Customer customer3 = new Customer("pavan",35, "pavan.infa@example.com");

	        // Display customer details
	        customer1.displayDetails();
	        customer2.displayDetails();
	        customer3.displayDetails();
	    }
	}


