package com.jt.i;

public class StringTest {

	public static void main(String[] args) {
		
	
	String s="Rathnakar";
	
	int count;
	
	char string[] = s.toCharArray();
	
	for(int i=0;i<string.length; i++)
	{
		count=1;
		for(int j=0;j<string.length; j++)
		{
			if(string[i] == string[j] && string[i]!= ' ')
{
	count++;
	string[j]='0';
}
		}
		
	}
	}
}
