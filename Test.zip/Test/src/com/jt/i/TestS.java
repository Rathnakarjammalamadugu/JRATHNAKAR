package com.jt.i;

public class TestS {
	
		public static void main(String[] args) {
			SingletonTest s1=SingletonTest.getSingletonTest();
			SingletonTest s2=SingletonTest.getSingletonTest();
			SingletonTest s3=SingletonTest.getSingletonTest();
			
			System.out.println(" HashCode of S1"+s1.hashCode());
			System.out.println(" HashCode of S2"+s2.hashCode());
			System.out.println(" HashCode of S3"+s3.hashCode());
		}
}
