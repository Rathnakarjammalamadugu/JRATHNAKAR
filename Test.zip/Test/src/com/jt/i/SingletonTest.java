package com.jt.i;

 class SingletonTest {
	private static SingletonTest single_instance=null;
	
	public String s;
	
	private SingletonTest()
	{
		s="I am string as part of SingletonTest class";
		System.out.println(s);
	}
	
	public static SingletonTest getSingletonTest()
	{
		if(single_instance == null)
			single_instance = new SingletonTest();
		return single_instance;
	}

}


