package com.example.Service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Repository.TransactionRepository;
import com.example.Transaction.Transaction;

@Service
public class RewardService {

    @Autowired
    private TransactionRepository transactionRepository;

    public int calculateRewards(double amount) {
        int points = 0;
        if (amount > 100) {
            points += 2 * (amount - 100);
            amount = 100;
        }
        if (amount > 50) {
            points += (amount - 50);
        }
        return points;
    }

    public int getRewardsByCustomerAndMonth(Long customerId, LocalDate startDate, LocalDate endDate) {
        List<Transaction> transactions = transactionRepository.findByCustomerIdAndDateBetween(customerId, startDate, endDate);
        return transactions.stream().mapToInt(t -> calculateRewards(t.getAmount())).sum();
    }

    public int getTotalRewards(Long customerId, LocalDate startDate, LocalDate endDate) {
        return getRewardsByCustomerAndMonth(customerId, startDate, endDate);
    }
}