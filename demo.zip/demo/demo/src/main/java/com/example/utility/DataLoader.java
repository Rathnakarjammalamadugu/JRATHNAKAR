package com.example.utility;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.Customer.Customer;
import com.example.Repository.CustomerRepository;
import com.example.Repository.TransactionRepository;
import com.example.Transaction.Transaction;

@Component
public class DataLoader implements CommandLineRunner {
    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Override
    public void run(String... args) throws Exception {
        Customer customer = new Customer();
        customer.setName("John Doe");
        customer = customerRepository.save(customer);

        Transaction transaction1 = new Transaction();
        transaction1.setCustomer(customer);
        transaction1.setAmount(120);
        transaction1.setDate(LocalDate.now().minusDays(10));
        transactionRepository.save(transaction1);

        Transaction transaction2 = new Transaction();
        transaction2.setCustomer(customer);
        transaction2.setAmount(80);
        transaction2.setDate(LocalDate.now().minusDays(20));
        transactionRepository.save(transaction2);
    }
}
